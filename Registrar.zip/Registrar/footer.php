<style>
.footer {
    position: fixed;
    bottom: 0;
    left: 0;
    height: 2%;
    width: 100%;
    z-index: 1000; /* Ensures it stays above other elements if needed */
}

</style>



<!-- footer.php -->
<footer class="footer pt-0 bg-dark text-white bg-opacity-75">
    <div class="container text-center">
        <p class="pb-4" style="font-size: 9px;">&copy; <?php echo date("Y"); ?> Registrar Management System | Developed by: Lovimen B. Decena</p>
    </div>
</footer>


