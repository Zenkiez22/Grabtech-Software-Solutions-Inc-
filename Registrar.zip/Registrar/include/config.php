<?php
$dbHost = "localhost"; // For shared hosting, this should remain 'localhost'
$dbUser = ""; // Database username
$dbPass = ""; // Database password
$dbName = ""; // Database name
$db = mysqli_connect($dbHost, $dbUser, $dbPass, $dbName);
?>